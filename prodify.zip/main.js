import './style.css'

document.querySelector('#site-header').innerHTML = `
  <div class="navigation-wrapper">
    <div>Header Area</div>
  </div>
`

document.querySelector('#site-footer').innerHTML = `
  <div class="footer-wrapper">
    <div>Footer Area</div>
  </div>
`